text = 'Hello World'

print(text)