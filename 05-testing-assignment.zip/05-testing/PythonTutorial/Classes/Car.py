import Vehicle

class Car (Vehicle.Vehicle):

    wheels = 4

    def get_num_wheels(self):
        return self.wheels